<?php

$_['payment_title'] = 'Paysafe:cash';
$_['error_payment'] = 'Unfortunately, your payment failed. Please try again';
$_['button_proceed'] = 'Proceed with Paysafe:cash';
